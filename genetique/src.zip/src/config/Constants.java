package config;

public class Constants {
	public static final int MIN_PANEL_SIZE = 500;
	public static final int DEFAULT_MODEL_SIZE = 40;
	public static int CAMERA_RANGE = 10;
}
