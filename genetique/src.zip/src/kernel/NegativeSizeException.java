package kernel;

public class NegativeSizeException extends Exception {
	private static final long serialVersionUID = 1L;
}
