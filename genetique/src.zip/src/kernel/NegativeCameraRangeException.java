package kernel;

public class NegativeCameraRangeException extends Exception {
	private static final long serialVersionUID = 1L;
}
