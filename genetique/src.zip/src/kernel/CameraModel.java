package kernel;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import config.Constants;

public class CameraModel {
	private List<CameraModelListenerInterface> listeners;
	private int size;
	private List<Camera> cameras;

	public CameraModel(int size) throws NegativeSizeException {
		this.cameras = new ArrayList<Camera>();
		this.listeners = new ArrayList<CameraModelListenerInterface>();
		this.setSizeAndResetCamera(size);
	}

	public void setSizeAndResetCamera(int size) throws NegativeSizeException {
		if (size <= 0)
			throw new NegativeSizeException();
		this.size = size;
		this.cameras.clear();
		this.notifyListeners();
	}

	public void addCamera(Camera camera) throws CameraOutOfBoundException {
		if (camera.getX() < 0 || camera.getX() >= size || camera.getY() < 0 || camera.getY() >= size) {
			throw new CameraOutOfBoundException();
		}
		this.cameras.add(camera);
		this.notifyListeners();
	}

	public void removeCamera(Camera camera) throws CameraNotFoundInListException {
		if (!this.cameras.remove(camera))
			throw new CameraNotFoundInListException();
		this.notifyListeners();
	}

	public void addListener(CameraModelListenerInterface listener) {
		this.listeners.add(listener);
	}

	public void removeListener(CameraModelListenerInterface listener) throws ListenerNotFoundInListException {

		if (!this.listeners.remove(listener))
			throw new ListenerNotFoundInListException();
	}

	private void notifyListeners() {
		for (CameraModelListenerInterface listener : listeners) {
			listener.cameraModelChanged(this);
		}
	}

	public int getSize() {
		return size;
	}

	public boolean isInCameraRange(int x, int y) {
		for (Camera c : this.cameras) {
			if (c.isInRange(x, y)) {
				return true;
			}
		}
		return false;
	}

	public boolean isCamera(int x, int y) {
		for (Camera c : this.cameras) {
			if (c.getX() == x && c.getY() == y) {
				return true;
			}
		}
		return false;
	}

	public Camera getCameraAt(int x, int y) {
		for (Camera c : this.cameras) {
			if (c.getX() == x && c.getY() == y) {
				return c;
			}
		}
		return null;
	}

	public int computeCoverage() {
		int coverage = 0;
		for (int x = 0; x < size; x++) {
			for (int y = 0; y < size; y++) {
				if (this.isInCameraRange(x, y)) {
					coverage++;
				}
			}
		}
		return coverage;
	}

	public void importFromFile(File f)
			throws FileNotFoundException, IOException, NotEnoughLinesException, CantParseCameraException,
			NumberFormatException, NegativeCameraRangeException, NegativeSizeException, CameraOutOfBoundException {
		try (BufferedReader br = new BufferedReader(new FileReader(f))) {
			String line = br.readLine();
			ArrayList<String> lines = new ArrayList<String>();

			while (line != null) {
				lines.add(line);
				line = br.readLine();
			}

			if (lines.size() < 1)
				throw new NotEnoughLinesException();

			String sizeString = lines.get(0);
			int sizeParsed = Integer.parseInt(sizeString);

			ArrayList<Camera> parsedCameras = new ArrayList<Camera>();

			for (int i = 1; i < lines.size(); i++) {
				String currentCameraString = lines.get(i);
				if (currentCameraString.equals(""))
					continue;

				if (!currentCameraString.contains(" "))
					throw new CantParseCameraException();

				String[] currentCameraStringSplit = currentCameraString.split(" ");
				if (currentCameraStringSplit.length != 2)
					throw new CantParseCameraException();

				int cameraX = Integer.parseInt(currentCameraStringSplit[0]);
				int cameraY = Integer.parseInt(currentCameraStringSplit[1]);

				parsedCameras.add(new Camera(cameraX, cameraY, Constants.CAMERA_RANGE));
			}

			this.setSizeAndResetCamera(sizeParsed);

			for (Camera c : parsedCameras)
				this.addCamera(c);
		}
	}

	public int getCameraCount() {
		return this.cameras.size();
	}

	public double getCameraDistRatio(int x, int y) {
		double min_ratio = 1;
		for (Camera c : this.cameras) {
			if (c.isInRange(x, y)) {
				double ratio = c.getDistRatio(x, y);
				if (ratio < min_ratio)
					min_ratio = ratio;
			}
		}
		return min_ratio;
	}
}
