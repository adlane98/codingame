package kernel;

public class NotEnoughLinesException extends Exception {
	private static final long serialVersionUID = 1L;
}
