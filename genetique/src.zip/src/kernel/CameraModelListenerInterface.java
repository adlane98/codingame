package kernel;

public interface CameraModelListenerInterface {
	public void cameraModelChanged(CameraModel cameraModel);
}
