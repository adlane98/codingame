package kernel;

public class CantParseCameraException extends Exception {
	private static final long serialVersionUID = 1L;
}
