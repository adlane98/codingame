package kernel;

public class Camera {
	private int x, y, range;

	public Camera(int x, int y, int range) throws NegativeCameraRangeException {
		if (range <= 0)
			throw new NegativeCameraRangeException();
		this.x = x;
		this.y = y;
		this.range = range;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public int getRange() {
		return range;
	}

	public boolean isInRange(int x2, int y2) {
		return (x - x2) * (x - x2) + (y - y2) * (y - y2) < range * range;
	}

	public double getDistRatio(int x2, int y2) {
		return (double)((x - x2) * (x - x2) + (y - y2) * (y - y2)) / (double)(range * range);
	}
}
