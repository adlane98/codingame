package kernel;

public class CameraNotFoundInListException extends Exception {
	private static final long serialVersionUID = 1L;
}
