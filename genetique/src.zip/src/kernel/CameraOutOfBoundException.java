package kernel;

public class CameraOutOfBoundException extends Exception {
	private static final long serialVersionUID = 1L;
}
