import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import config.Constants;
import gui.MainWindow;
import kernel.CameraModel;
import kernel.CameraOutOfBoundException;
import kernel.CantParseCameraException;
import kernel.NegativeCameraRangeException;
import kernel.NegativeSizeException;
import kernel.NotEnoughLinesException;

public class Main {

	public static void main(String[] args) {
		if (args.length > 1) {
			System.out.println(
					"This program is not meant to be used with more than 2 arguments. Call it with either nothing to show the GUI or with a solution file.");
			return;
		}
		if (args.length == 1) {
			try {
				CameraModel cameraModel = new CameraModel(Constants.DEFAULT_MODEL_SIZE);
				cameraModel.importFromFile(new File(args[0]));
				System.out.println("Coverage : " + cameraModel.computeCoverage());
			} catch (NumberFormatException e) {
				System.out.println(
						"ERROR : Invalid file format.\nFailed to parse a number.\nFirst line should be the map size.\nFollowing lines should be camera coordinates separated by a space, as 'x y'");
			} catch (FileNotFoundException e) {
				System.out.println("ERROR : File not found");
			} catch (IOException e) {
				System.out.println("ERROR : IOException");
			} catch (NotEnoughLinesException e) {
				System.out.println(
						"ERROR : Invalid file format.\nFirst line should be the map size.\nFollowing lines should be camera coordinates separated by a space, as 'x y'");
			} catch (CantParseCameraException e) {
				System.out.println(
						"ERROR : Invalid file format.\nCan't parse cameras\nFirst line should be the map size.\nFollowing lines should be camera coordinates separated by a space, as 'x y'");
			} catch (NegativeCameraRangeException e) {
				System.out.println("ERROR : Invalid camera range");
			} catch (NegativeSizeException e) {
				System.out.println(
						"ERROR : Invalid file format.\nFirst line should be the map size (non-negative).\nFollowing lines should be camera coordinates separated by a space, as 'x y'");
			} catch (CameraOutOfBoundException e) {
				System.out.println(
						"ERROR : One camera is out of bounds. Please remember that for each camera, x < size and y < size, with size the size of the map");
			}
		} else {
			CameraModel cameraModel;
			try {
				cameraModel = new CameraModel(Constants.DEFAULT_MODEL_SIZE);
				MainWindow mainWindow = new MainWindow(cameraModel);
				mainWindow.setVisible(true);
			} catch (NegativeSizeException e) {
				System.out.println("Internal Error");
			}
		}
	}
}
