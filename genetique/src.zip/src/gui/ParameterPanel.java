package gui;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import kernel.CameraModel;
import kernel.CameraModelListenerInterface;
import kernel.CameraOutOfBoundException;
import kernel.CantParseCameraException;
import kernel.NegativeCameraRangeException;
import kernel.NegativeSizeException;
import kernel.NotEnoughLinesException;

public class ParameterPanel extends JPanel implements CameraModelListenerInterface {
	private static final long serialVersionUID = 1L;
	private CameraModel cameraModel;
	private JTextField sizeText;
	private JLabel coverageLabel;
	private JLabel camerasLabel;

	public ParameterPanel(CameraModel cameraModel) {
		this.cameraModel = cameraModel;

		cameraModel.addListener(this);

		this.setLayout(new GridLayout(4, 2));
		
		this.add(new JLabel("Coverage"));
		this.add(coverageLabel = new JLabel());
		
		this.add(new JLabel("Cameras"));
		this.add(camerasLabel = new JLabel());

		this.add(new JLabel("Size"));
		this.add(sizeText = new JTextField());

		JButton importButton = new JButton("Import File");
		importButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				importFile();
			}
		});
		this.add(importButton);

		JButton applyButton = new JButton("Apply");
		applyButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				applyParams();
			}
		});
		this.add(applyButton);

		this.notifyModelChanged();
	}

	private void importFile() {
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("File to import");
		fileChooser.setCurrentDirectory(new File(System.getProperty("user.dir")));
		int retval = fileChooser.showOpenDialog(this);
		if (retval == JFileChooser.CANCEL_OPTION) {
			return;
		}
		if (retval == JFileChooser.ERROR_OPTION){
			JOptionPane.showMessageDialog(this, "JFileChooser.ERROR_OPTION", "Internal Error",
					JOptionPane.ERROR_MESSAGE);
		}
		if (retval == JFileChooser.APPROVE_OPTION) {
			File f = fileChooser.getSelectedFile();
			try {
				this.cameraModel.importFromFile(f);
			} catch (NumberFormatException e) {
				JOptionPane.showMessageDialog(this, "Invalid file format.\nFailed to parse a number.\nFirst line should be the map size.\nFollowing lines should be camera coordinates separated by a space, as 'x y'", "Input Error",
						JOptionPane.ERROR_MESSAGE);
			} catch (FileNotFoundException e) {
				JOptionPane.showMessageDialog(this, "File not found", "Input Error",
						JOptionPane.ERROR_MESSAGE);
			} catch (IOException e) {
				JOptionPane.showMessageDialog(this, "IOException", "Internal Error",
						JOptionPane.ERROR_MESSAGE);
			} catch (NotEnoughLinesException e) {
				JOptionPane.showMessageDialog(this, "Invalid file format.\nFirst line should be the map size.\nFollowing lines should be camera coordinates separated by a space, as 'x y'", "Input Error",
						JOptionPane.ERROR_MESSAGE);
			} catch (CantParseCameraException e) {
				JOptionPane.showMessageDialog(this, "Invalid file format.\nCan't parse cameras\nFirst line should be the map size.\nFollowing lines should be camera coordinates separated by a space, as 'x y'", "Input Error",
						JOptionPane.ERROR_MESSAGE);
			} catch (NegativeCameraRangeException e) {
				JOptionPane.showMessageDialog(this, "Invalid camera range", "Input Error",
						JOptionPane.ERROR_MESSAGE);
			} catch (NegativeSizeException e) {
				JOptionPane.showMessageDialog(this, "Invalid file format.\nFirst line should be the map size (non-negative).\nFollowing lines should be camera coordinates separated by a space, as 'x y'", "Input Error",
						JOptionPane.ERROR_MESSAGE);
			} catch (CameraOutOfBoundException e) {
				JOptionPane.showMessageDialog(this, "One camera is out of bounds. Please remember that for each camera, x < size and y < size, with size the size of the map", "Input Error",
						JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	private void computeCoverage() {
		int coverage = this.cameraModel.computeCoverage();

		coverageLabel.setText(String.valueOf(coverage));
	}
	
	private void updateModelSizeLabel() {
		sizeText.setText(String.valueOf(cameraModel.getSize()));
	}
	
	private void notifyModelChanged() {
		this.computeCoverage();
		this.updateModelSizeLabel();
		this.updateCamerasLabel();
	}

	private void updateCamerasLabel() {
		camerasLabel.setText(String.valueOf(cameraModel.getCameraCount()));
	}

	private void applyParams() {
		String size = sizeText.getText();
		try {
			cameraModel.setSizeAndResetCamera(Integer.parseInt(size));
		} catch (NumberFormatException e1) {
			JOptionPane.showMessageDialog(this, "Number formatted incorrectly", "Input Error",
					JOptionPane.ERROR_MESSAGE);
		} catch (NegativeSizeException e1) {
			JOptionPane.showMessageDialog(this, "Negative size not allowed", "Input Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	@Override
	public void cameraModelChanged(CameraModel cameraModel) {
		this.notifyModelChanged();
	}
}
