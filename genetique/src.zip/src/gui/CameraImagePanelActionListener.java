package gui;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JOptionPane;

import config.Constants;
import kernel.Camera;
import kernel.CameraModel;
import kernel.CameraNotFoundInListException;
import kernel.CameraOutOfBoundException;
import kernel.NegativeCameraRangeException;

public class CameraImagePanelActionListener implements MouseListener {
	private CameraModel cameraModel;
	private CameraImagePanel cameraImagePanel;

	public CameraImagePanelActionListener(CameraImagePanel cameraImagePanel, CameraModel cameraModel) {
		this.cameraImagePanel = cameraImagePanel;
		this.cameraModel = cameraModel;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		int graphicX = e.getX();
		int graphicY = e.getY();

		int x = (graphicX * this.cameraModel.getSize()) / this.cameraImagePanel.getWidth();
		int y = (graphicY * this.cameraModel.getSize()) / this.cameraImagePanel.getHeight();

		if (this.cameraModel.getCameraAt(x, y) != null) {
			try {
				this.cameraModel.removeCamera(this.cameraModel.getCameraAt(x, y));
			} catch (CameraNotFoundInListException e1) {
				JOptionPane.showMessageDialog(cameraImagePanel, "CameraNotFoundInListException", "Internal error",
						JOptionPane.ERROR_MESSAGE);

			}
		} else {
			try {
				this.cameraModel.addCamera(new Camera(x, y, Constants.CAMERA_RANGE));
			} catch (CameraOutOfBoundException e1) {
				JOptionPane.showMessageDialog(cameraImagePanel, "CameraNotFoundInListException", "Internal error",
						JOptionPane.ERROR_MESSAGE);
			} catch (NegativeCameraRangeException e1) {
				JOptionPane.showMessageDialog(cameraImagePanel, "NegativeCameraRangeException", "Internal error",
						JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}
}
