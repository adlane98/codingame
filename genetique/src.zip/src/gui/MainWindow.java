package gui;

import java.awt.BorderLayout;
import java.awt.HeadlessException;

import javax.swing.JFrame;

import kernel.CameraModel;

public class MainWindow extends JFrame {
	private static final long serialVersionUID = 1L;

	public MainWindow(CameraModel cameraModel) throws HeadlessException {
		super("Camera Main Window");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);

		BorderLayout layout = new BorderLayout();
		this.setLayout(layout);
		this.add(new CameraImagePanel(cameraModel), BorderLayout.CENTER);
		this.add(new ParameterPanel(cameraModel), BorderLayout.SOUTH);
		this.pack();
	}
}
