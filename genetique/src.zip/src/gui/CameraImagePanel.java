package gui;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

import config.Constants;
import kernel.CameraModel;
import kernel.CameraModelListenerInterface;

public class CameraImagePanel extends JPanel implements CameraModelListenerInterface {
	private static final long serialVersionUID = 1L;
	private CameraModel cameraModel;
	private BufferedImage displayedImage;

	public CameraImagePanel(CameraModel cameraModel) {
		this.cameraModel = cameraModel;
		this.cameraModel.addListener(this);
		Dimension minDim = new Dimension(Constants.MIN_PANEL_SIZE, Constants.MIN_PANEL_SIZE);
		this.setMinimumSize(minDim);
		this.setPreferredSize(minDim);
		updateImageWithModel();
		this.addMouseListener(new CameraImagePanelActionListener(this, cameraModel));
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		synchronized (this) {
			if (this.displayedImage != null) {
				int height = this.getSize().height;
				int width = this.getSize().width;
				g.drawImage(displayedImage, 0, 0, width, height, this);
			}
		}
	}

	private void updateImageWithModel() {
		BufferedImage result;
		synchronized (this.cameraModel) {
			int width = this.cameraModel.getSize();
			int height = this.cameraModel.getSize();
			result = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

			for (int x = 0; x < width; x++) {
				for (int y = 0; y < height; y++) {
					result.setRGB(x, y, 0xffffff);
					if (this.cameraModel.isInCameraRange(x, y)) {
						double delta = this.cameraModel.getCameraDistRatio(x, y);
						delta = 1 - delta / 2.0;

						int r = (int)(delta * 0xff + (1 - delta) * 0xff);
						int g = (int)(delta * 0x99 + (1 - delta) * 0xff);
						int b = (int)(delta * 0x33 + (1 - delta) * 0xff);

						result.setRGB(x, y, r * 0x10000 + g * 0x100 + b);
					}
					if (this.cameraModel.isCamera(x, y)) {
						result.setRGB(x, y, 0x000000);
					}
				}
			}
		}

		synchronized (this) {
			this.displayedImage = result;
		}
		this.repaint();
	}

	@Override
	public void cameraModelChanged(CameraModel cameraModel) {
		this.updateImageWithModel();
	}
}
